
const Card = (props) => {
    return (
        <section className="d-flex justify-content-between border p-2 m-2 align-items-center">
            <h2>{props.card.question}</h2>
            <div>
                <button>Voir la réponse</button>
                <h3>{props.card.answer}</h3>
                <h3>{props.card.explanation}</h3>
            </div>
        </section>
    );
}

export default Card;