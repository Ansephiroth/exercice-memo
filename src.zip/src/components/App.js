import Button from "./Button";
import { useState } from "react";
import Memoform from './Memoform';
import Card from "./Card";

function App() {
  // Etablir l'état initial du formulaire.
  const [formVisibility, setFormVisibility] = useState(false);
  // Etat du gestionnaire d'état du formulaire.
  const [cards, setCards] = useState([]);
  //Gestion de l'ajout d'une tâche
  function handleSubmitCard(event, new_card) {
    console.log("handleSubmitCard", new_card);
    setCards([...cards, new_card])
  }


  return (
    <div className="App">
      <Button
        setFormVisibility={setFormVisibility}
      />
      {/*Conditional rendering in react */}
      {formVisibility && <Memoform handleSubmitCard={handleSubmitCard} />}
      {/*Utiliser map pour parcourir le contenu de cards */}
      {cards.map(card => <Card
      card={card}
      key={Math.random*10000}
      handleSubmitCard={handleSubmitCard}
      />
      )}
    </div>
  );
}

export default App;
